
// This is my own personal LiceNse.

int main(void) {
        return 0;
}
